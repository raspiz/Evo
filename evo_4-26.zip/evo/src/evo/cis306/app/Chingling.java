package evo.cis306.app;

public class Chingling extends MobileCritter{

	public Chingling()
	{//default
		super();
	}
	public Chingling(int pX, int pY, int pPhase, int pDigest, int pAge, boolean pFull, String pSpecies, String pFileName)
	{
		super(pX, pY, pPhase, pDigest, pAge, pFull, pSpecies, pFileName);	
		int MoveX = super.MoveX("chingling");
		int MoveY = super.MoveY("chingling");
		int MaxAge = super.MaxAge("chingling");
	}
	
	
}
