package evo.cis306.app;

public class StationaryCritter extends Critter{

	
	public StationaryCritter()
	{
		super();
	}
	
	public StationaryCritter(int pX, int pY, int pPhase, int pDigest, int pAge, boolean pFull, String pSpecies, String pFileName)
	{
		super(pX, pY, pPhase, pDigest, pAge, pFull, pSpecies, pFileName);
		
	}
	
}
