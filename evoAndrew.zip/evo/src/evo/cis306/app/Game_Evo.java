package evo.cis306.app;

import java.util.Random;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.*;


public class Game_Evo extends JPanel{
	
	public final int WIDTH = 300;
	public final int HEIGHT = 300;
	// Speed of game

	private Critter daGuy;
	private int daGuyInt;
	private Random generator;
	
	
	// arraylist to hold individual species
	private ArrayList<Deeproot> deeproot;
	private ArrayList<Catcher> catcher;
	private ArrayList<Spore> spore;
	
	
	// arraylist of arraylists. each species is an index in the arraylist

	// 1  - deeproot
	// 2 - catcher
	// n-1 - spore - keep as last element in array		
	private ArrayList<ArrayList> critList;
	


	
	protected Game_World world;


	
	private Critter currentCritter;
	
	protected Timer timer;	


	public Game_Evo()
	{
		// load parameters for the game world
		// could derive classes from this for different testing and balancing
		world = new Game_World();		
		
		
		timer = new Timer(world.getSpeed(), new TimerListener());
		

		
		// create deeproot arraylist and add it to total critter arraylist
		////**********************
		// need to add all species to this as they are implemented
		////**********************
		deeproot = new ArrayList<Deeproot>(20);	
		catcher = new ArrayList<Catcher>();
		spore = new ArrayList<Spore>();
		//critList = new ArrayList<ArrayList>(1);
		critList = new ArrayList<ArrayList>();
				

		critList.add(deeproot);
		critList.add(catcher);
		// MAKE SURE SPORE IS ADDED TO THE ARRAYLIST LAST!
		critList.add(spore);
		
		generator = new Random();			
	}
	

	/******************************
	 * POPULATE
	 * 
	 * at start of game and if there are less than 20 deeproots in the game,
	 * 20 deeproots will be populated
	 * 
	 * might want to change this to spawn spores instead of deeproots
	 * 
	 ******************************/
	public void Populate()
	{		
		int stuckCount = 0;
		
		// might want to change condition here. could make it spawn spores rather than deeproots
		while (deeproot.size() < 20 && stuckCount < 1000)			
		{
			int startX = 0;
			int startY = 0;
			
			
			// change condition here to account for 3x3 pixel size
			// may want to abstract out into a separate method
			//do
			//{
				startX = generator.nextInt(WIDTH); // 0 to (n-1)
				startY = generator.nextInt(HEIGHT);
				
			//}while (startX > WIDTH || startX < 0 || startY > HEIGHT || startY < 0);
			
			//System.out.println("x: " + startX + " | y: " + startY);
			
			// check for collisions and room to be added	
			currentCritter = new Deeproot(startX, startY, 1, 0, 0, false, "deeproot", "deeproot1.png");	
				
			
			
			if (!CollisionDetect(currentCritter))
			{
				
				currentCritter.loadImage();
				currentCritter.setImage(currentCritter.getImage());
				
				// add to arraylist
				// cast it as a deeproot
				deeproot.add((Deeproot)currentCritter);				
				
			}
			
			stuckCount++;
				
				
			//System.out.println(currentCritter.getSpecies() + "  " + critters.size() + " X:" + currentCritter.getxLoc() + " Y:" + currentCritter.getyLoc());
			
		}
			
		


		
	}
	
	/*********************************
	 * THIS IS THE MAIN GAME FUNCTION.
	 * 
	 * CALLED EACH TIME THE TIMER TICKS
	 *********************************/
	private class TimerListener implements ActionListener
	{
		
		//The listener that triggered when the timer goes off
		public void actionPerformed(ActionEvent arg0) 
		{			
			// perform one cycle of the game

			int maxX;
			int maxY;
			Populate();

			///// foreach loop
			// age up
			//generate movement
			//check if hungry
				//try to eat if hungry while moving
			// check for growth
			// resize if growing		
			// if > phase 2, create spores 
			// die if too old
			// draw
			// 
			

			for (int i = 0; i < critList.size(); i++)
			{
				Critter myCritter;
				
				ArrayList<Critter> speciesList = (ArrayList<Critter>)critList.get(i);
				
				if (speciesList != null)  // makes sure this will not cause an error when a species goes extinct
				{
					for (int j = 0; j < speciesList.size(); j++)
						{
							myCritter = speciesList.get(j);
							if (myCritter.species == "deeproot" || myCritter.species == "catcher")
								{
									// age 1 year
									
									int vAge = CritterAgeUp(myCritter, myCritter.age);						
									
									if (vAge <= myCritter.getMaxAge(myCritter.species)) // false if ready to die
									{											
										int phaseUpInterval = myCritter.getMaxAge(myCritter.species) / 5;	
										
										// try to phase up
										if (vAge % phaseUpInterval == 0)
										{								
											if (myCritter.phase < 5)
											{									
												// try to grow
												// if it grows, change set the x and y centers with critter.UpdateSprite();
			
												
												// phase up
												myCritter.setPhase(myCritter.getPhase() + 1);
												// move critter up and left 1 space to keep growth radius centered											
												myCritter.setxLoc(myCritter.getxLoc() - 1);
												myCritter.setyLoc(myCritter.getyLoc() - 1);
												myCritter.updateSprite();
												
			
												// try to collide
												// if there is a collision, reset phase and size
												if(CollisionDetect(myCritter) || myCritter.getxLoc() < 0 || myCritter.getxLoc() >= WIDTH || myCritter.getyLoc() < 0 || myCritter.getyLoc() >= HEIGHT)
												{
													//int derp = myCritter.getPhase();
													//derp = derp - 1;
													myCritter.setPhase(myCritter.getPhase() - 1);
													myCritter.setxLoc(myCritter.getxLoc() + 1);
													myCritter.setyLoc(myCritter.getyLoc() + 1);
													//myCritter.setPhase(derp);
			
													myCritter.updateSprite();
			
													
													//System.out.println("what's wrong");
													
												}
												
												
												// change output image. concatenate a string for the filename
												myCritter.setFilename(myCritter.species + myCritter.phase + ".png");	
												myCritter.loadImage();										
																							
												
												//System.out.println("I am " + myCritter.getAge() + " and on phase " + myCritter.phase);// + " number + " + critters.size());
			
												int sporesOut = world.getSporesReleased();
												
											    // 100 means 1 spore, 150 means 1.5 spores, etc
												// can't remember why i did it this way. could be tweaked
									            if (myCritter.phase > 2)	// create spores if they are past the 2 phase
									                if (sporesOut >= 150)
									                {
									                    CreateSpore(myCritter);
									                    if (sporesOut >= 200 || myCritter.age % 2 == 0)
									                        CreateSpore(myCritter);
									                }
									                else if (sporesOut >= 50)                    
									                    if (sporesOut >= 100 || myCritter.age % 2 == 0)
									                        CreateSpore(myCritter);																		
											}
											
										}
																		
									}
									else
									{		
										
										// after a certain age they will no longer reproduce or try to phase up. each cycle there is a chance they will die and be removed
										
										// made this a chance to die after a certain age rather than certain death
										// could make this affected by weather, temp zone, species
										if (generator.nextInt(100) < world.getDeathChance())
										{
											myCritter = null;
											speciesList.remove(j);
											j--;
										}
									}
									
							}
					else //critter is mobile
					{
						for (int j1 = 0; j1 < speciesList.size(); j1++)
						{
							myCritter = speciesList.get(j1);
							maxX = myCritter.getMoveX(myCritter.species);
							maxY = myCritter.getMoveY(myCritter.species);
							
							// age 1 year
							
							int vAge = CritterAgeUp(myCritter, myCritter.age);						
							
							if (vAge <= myCritter.getMaxAge(myCritter.species)) // false if ready to die
							{											
								int phaseUpInterval = myCritter.getMaxAge(myCritter.species) / 5;	
								
								// try to phase up
								if (vAge % phaseUpInterval == 0)
								{								
									if (myCritter.phase < 5)
									{									
										// try to grow
										// if it grows, change set the x and y centers with critter.UpdateSprite();
	
										
										// phase up
										myCritter.setPhase(myCritter.getPhase() + 1);
										// move critter up and left 1 space to keep growth radius centered											
										myCritter.setxLoc(myCritter.getxLoc() - 1);
										myCritter.setyLoc(myCritter.getyLoc() - 1);
										myCritter.updateSprite();
										
	
										// try to collide
										// if there is a collision, reset phase and size
										if(CollisionDetect(myCritter) || myCritter.getxLoc() < 0 || myCritter.getxLoc() >= WIDTH || myCritter.getyLoc() < 0 || myCritter.getyLoc() >= HEIGHT)
										{
											//int derp = myCritter.getPhase();
											//derp = derp - 1;
											myCritter.setPhase(myCritter.getPhase() - 1);
											myCritter.setxLoc(myCritter.getxLoc() + 1);
											myCritter.setyLoc(myCritter.getyLoc() + 1);
											//myCritter.setPhase(derp);
	
											myCritter.updateSprite();
	
											
											//System.out.println("what's wrong");
											
										}
										
										
										// change output image. concatenate a string for the filename
										myCritter.setFilename(myCritter.species + myCritter.phase + ".png");	
										myCritter.loadImage();										
																					
										
										//System.out.println("I am " + myCritter.getAge() + " and on phase " + myCritter.phase);// + " number + " + critters.size());
	
										int sporesOut = world.getSporesReleased();
										
									    // 100 means 1 spore, 150 means 1.5 spores, etc
										// can't remember why i did it this way. could be tweaked
							            if (myCritter.phase > 2)	// create spores if they are past the 2 phase
							                if (sporesOut >= 150)
							                {
							                    CreateSpore(myCritter);
							                    if (sporesOut >= 200 || myCritter.age % 2 == 0)
							                        CreateSpore(myCritter);
							                }
							                else if (sporesOut >= 50)                    
							                    if (sporesOut >= 100 || myCritter.age % 2 == 0)
							                        CreateSpore(myCritter);																		
									}
									
								}
																
							}
							else
							{		
								
								// after a certain age they will no longer reproduce or try to phase up. each cycle there is a chance they will die and be removed
								
								// made this a chance to die after a certain age rather than certain death
								// could make this affected by weather, temp zone, species
								if (generator.nextInt(100) < world.getDeathChance())
								{
									myCritter = null;
									speciesList.remove(j1);
									j1--;
								}
							}
							Random random = new Random();
							int moveX, moveY;
							moveX = random.nextInt(maxX)+1;
							moveY = random.nextInt(maxY)+1;
							for (int x=0; x<moveX; x++)
							{
								myCritter.xLoc++;
								for(int y=0; y<maxY; y++)
								{
									myCritter.yLoc++;
									
									//check collisions
									if(CollisionDetect(myCritter) == true)
									{
									//check to eat
										if(!myCritter.full)
										{
											//false, can eat
											String sp = daGuy.species;
											int index;
											if (sp == "deeproot")
											{
												index = 0;
											}
											else if (sp == "catcher")
											{
												index = 1;
											}
											else if (sp == "chingling")
											{
												index = 2;
											}
											else if (sp == "marmot")
											{
												index = 3;
											}
											else if (sp == "zylot")
											{
												index = 4;
											}
											else
											{
												//spore
												break;
											}
											
											myCritter.full = true;
											myCritter.digest = 3;
											ArrayList<Critter> removeCrit = (ArrayList<Critter>)critList.get(index); 
											//gets the array list of type of critter to be removed
											removeCrit.remove(daGuyInt); //removes critter
										}
										if(myCritter.full)
										{
											//true, can't eat
											break;
										}

										
									}
									else //no collision, so can move
										//move
									break;
								}
							}
							
						}
					}
				}
				}

			
			// cycle through each species behavior
			// age, phaseup, die, move, eat, etc
			for (i = 0; i < critList.size(); i++)
			{
				
				switch (i)
				{
						// spore behavior
					    // keep this as the last behavior so they don't take action right after being born
						case 1:
							if (spore != null)
							{
								for (int j = 0; j < spore.size(); j++)
								{
									
									// returns the creature as an object
									myCritter = spore.get(j);								
									
									// age 1 year
									int vAge = CritterAgeUp(myCritter, myCritter.getAge());
						
							        if (vAge >= 5 && vAge < 10)	// if spore is old enough, there's a chance of growing up
							        {
							        	
							        	byte mutate = (byte)generator.nextInt(100); // 0 to 1. could parameterize this and make the chance of mutation go up or down based on conditions or temp zone
							  
							        	// not done yet							        	
							        	// add another condition above here for each species added	
							        	// need to account for additional size of phase 1 creature, check for collisions
							            // trying up 2, down 1 for evolve for now
							            // species can only mutate 2 above and 1 below itself           
							            // spore will mutate into a new species if random number is within range  		
							        	
							        	//System.out.println("my species is " + myCritter.species);
							        	
							        	
							            if (mutate <= 20 && (myCritter.species.equals("catcher") || myCritter.species.equals("chingling")))	// 5% chance to mutate to catcher
							            {
							                // create catcher				
							                currentCritter = new Catcher(myCritter.xLoc, myCritter.yLoc, myCritter.phase, myCritter.digest, myCritter.age, myCritter.full, "catcher", "catcher1.png");
							                
							                // collision check
							                if (!CollisionDetect(currentCritter))
							                {
							                	catcher.add((Catcher)currentCritter);						               
							                
								                // delete spore
								                spore.remove(j);
								                j--;
							                }	
							            }	
							            else if (mutate <= world.getGrowChance() && (myCritter.species.equals("deeproot") || myCritter.species.equals("catcher")))  // chance to grow into deeproot, based on user control
							            {
							                // create new deeproot				
							                currentCritter = new Deeproot(myCritter.xLoc, myCritter.yLoc, myCritter.phase, myCritter.digest, myCritter.age, myCritter.full, "deeproot", "deeproot1.png");
							                
							                //System.out.println("hello");
							                
							                // collision check
							                if (!CollisionDetect(currentCritter))
							                {
							                	deeproot.add((Deeproot)currentCritter);						               
							                
								                // delete spore
								                spore.remove(j);
								                j--;
							                }
							            }

							        	
							        }
							        else if (vAge >= 10)	// kill spore if it has not become a creature and has gotten too old
							        {
						                // delete spore
							        	myCritter = null;
										spore.remove(j);
										j--;
							        } 		
								}
							}
							break;				

				}				
			}		
		
			// age the world by 1
			world.setGeneration(world.getGeneration() + 1);
			
			repaint(); // calls paintComponent and draws all of the creatures to the screen
			
			System.out.println("Generation: " + world.getGeneration());		
	
	}
}
}
	
	/************************
	 * CreateSpore - a creature is passed in and a spore
	 * of that species will be born
	 * 
	 * @param pParent
	 * @param pSpecies
	 ***********************/
	public void CreateSpore(Critter pParent)
	{
		int spawnX = 0;
		int spawnY = 0;
		int dirX, dirY;
		boolean collision = false; // need to add functionality
		int distance = world.getSporeDistance(); // distance spore can travel away from parent based on game world parameter
		
		// find a random spawn point from 0-distance away from parent.
		// switch tacks on parent size based on phase so that spore does not spawn on top of parent
		switch (pParent.getPhase())
		{
			case 1:
	            spawnX = generator.nextInt(distance) + 2;	
	            spawnY = generator.nextInt(distance) + 2;	
				break;
			case 2:
	            spawnX = generator.nextInt(distance) + 3;	
	            spawnY = generator.nextInt(distance) + 3;	
				break;
			case 3:
	            spawnX = generator.nextInt(distance) + 5;	
	            spawnY = generator.nextInt(distance) + 5;	
				break;
			case 4:
	            spawnX = generator.nextInt(distance) + 7;	
	            spawnY = generator.nextInt(distance) + 7;	
				break;
			case 5:
	            spawnX = generator.nextInt(distance) + 9;	
	            spawnY = generator.nextInt(distance) + 9;	
				break;	
		}
		
		// determine if the spore moves north/south and east/west
	    dirX = generator.nextInt(2);
	    dirY = generator.nextInt(2);
	    
	    if (dirX == 0)	// east
	    {
	        spawnX = pParent.getxCenter() + spawnX;
	        if (dirY == 0)	// north						
	            spawnY = pParent.getyCenter() - spawnY;						
	        else	// south						
	            spawnY = pParent.getyCenter() + spawnY;						
	    }
	    else	// west
	    {
	        spawnX = pParent.getxCenter() - spawnX;
	        if (dirY == 0)	// north						
	            spawnY = pParent.getyCenter() - spawnY;						
	        else	// south						
	            spawnY = pParent.getyCenter() + spawnY;						
	    } 
		
	    // create spore. not added to arraylist until we're 
	    //sure it won't collide with an existing creature
	    // or spawn out of bounds
	    currentCritter = new Spore(spawnX, spawnY, 0, 0, 0, false, pParent.species, "spore.png");
	    
	    if (spawnX >= 0 && spawnX < WIDTH && spawnY >= 0 && spawnY < HEIGHT) // make sure spawn loc is within borders
	    	collision = false; 	    
	    else
	    	collision = true;	    

	    if (!collision)
	    	collision = CollisionDetect(currentCritter); // try to collide with all of the other creatures	    
	    
	    // if all good, add to spore arraylist
	    if(!collision)	    
	    	spore.add((Spore)currentCritter);
	    
		
	}	
	
	// need to implement this for creatures growing
	// and spores mutating. if they can't move up to 3x3 then can't mutate
	public boolean CollisionDetect(Critter pMovingCritter)
	{
	    
		// try to use same method that draw uses, polymorphic
		// check species and index to ensure they don't collide with themselves
		// new spores pass in -1 since they are not in the array yet
		
		
		
		for (int i = 0; i < critList.size(); i++)
		{			
			// POLYMORPHISM!
			ArrayList<Critter> speciesList = (ArrayList<Critter>)critList.get(i);
			
			for (int j = 0; j < speciesList.size(); j++)
			{
				
				daGuy = speciesList.get(j);
				daGuyInt = j;
				
				if (pMovingCritter != daGuy) // ignores itself				
			    	if (pMovingCritter.boundingBox.intersects(daGuy.boundingBox))				    	
			    		return true; // we have a collision
			}
			
		}	

		return false;
	}
	
	
	/************************
	 * CritterAgeUp - age a passed in critter 1 year and return the value
	 * 
	 * @param pCritter
	 * @param pAge
	 * @return
	 ***********************/
	public int CritterAgeUp(Critter pCritter, int pAge)
	{
		pAge++;		
		pCritter.setAge(pAge);	
		return pAge;		
	}
	
	
	//Start the timer object
	public void startTimer()
	{
		timer.start();
		
	
	}
	
	// Stop the timer object
	public void stopTimer()
	{
		timer.stop();
	}
	
	
	
	/**********************
	 * paintComponent - draw the creatures to the screen at the end of every cycle
	 * 
	 * 
	 *********************/
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		//g.setColor(Color.RED);
		//g.drawLine(200, 200, 300, 300);
		
		Critter c;
		
		for (int i = 0; i < critList.size(); i++)
		{	
			// POLYMORPHISM!
			ArrayList<Critter> speciesList = (ArrayList<Critter>)critList.get(i);
			
			for (int j = 0; j < speciesList.size(); j++)
			{
				
				c = speciesList.get(j);
				c.draw(g);
			}
			
		}		
	}

	
	
}
