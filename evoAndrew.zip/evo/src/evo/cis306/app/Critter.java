package evo.cis306.app;

import java.awt.Rectangle;

// make abstract
public abstract class Critter extends Image_Entity{

	
    //var sporeProto = {x: spawnX, y: spawnY, tzone: tempzone, age: 0, phase: 0, species: parentSpecies};
	

	protected int phase;
	protected int digest;
	protected int age;	
	protected boolean full;
	protected String species;	
	protected int maxAge;
	protected int moveX, moveY;	

	
	protected int pixels;
    protected Rectangle boundingBox;
    
    public Critter()
    {
    	moveX = 0;
    	moveY = 0;
    	phase = 0;
    	age = 0;
    	digest = 0;
    	full = false;
    	species = "";  	
    	pixels = 1;
    	boundingBox = null;
    	maxAge = 0;
    }
    



	// parameterized constructor
    public Critter (int pX, int pY, int pPhase, int pDigest, int pAge, boolean pFull, String pSpecies, String pFileName)
    {
    	
    	// determine x and y center here
    	
    	
    	super(pX, pY, pFileName);
    	
    	//setxCenter(pX);
    	//setyCenter(pY);
    	
    	setPhase(pPhase);
    	setAge(pAge);
    	setDigest(pDigest);
    	setFull(pFull);
    	setSpecies(pSpecies);   	
		getMoveX(pSpecies);
		getMoveY(pSpecies);
    	updateSprite();
    }
    
    
	public void updateSprite()
	{
	
		//image.getWidth(null);
		
    	setxCenter();
    	setyCenter();
    	
    	switch (phase)
    	{
    		case 0:
    			setPixels(1);
    			break;
    		case 1:
    			setPixels(3);
    			break;
    		case 2:
    			setPixels(5);
    			break;
    		case 3:
    			setPixels(7);
    			break;
    		case 4:
    			setPixels(9);
    			break;
    		case 5:
    			setPixels(11);
    			break;
    	
    	}

    	
    	// remake bounding box with new size
    	setBoundingBox();
    	
//		
		//System.out.println("original x: " + xLoc + " | new x: " + xCenter);
		//System.out.println("original y: " + yLoc + " | new y: " + yCenter);

	}    
    

    
    

    // accessors and mutators
	
	public int getMaxAge(String pSpecies)
	 {
		 if (pSpecies == "chingling" )
		 {
			 maxAge = 100;
		 }
		 else if (pSpecies == "marmot")
		 {
			 maxAge = 50;
		 }
		 else if (pSpecies == "zylot")
		 {
			 maxAge = 50;
		 }
		 else if (pSpecies == "deeproot")
		 {
			 maxAge = 100;
		 }
		 else if (pSpecies == "catcher")
		 {
			 maxAge = 150;
		 }
		 return maxAge;
	 }
	public int getMoveX(String pSpecies)
	 {   //check the species of the critter
		 //generate a random up to the max move value of the species
		 if (pSpecies == "chingling" )
		 {
			 moveX = 1;
		 }
		 else if (pSpecies == "marmot")
		 {
			 moveX = 5;
		 }
		 else if (pSpecies == "zylot")
		 {
			 moveX = 10;
		 }
		 return moveX;
	 }
	public int getMoveY(String pSpecies)
	 {
		 //same as above
		 if (pSpecies == "chingling" )
		 {
			 moveY = 1;
		 }
		 else if (pSpecies == "marmot")
		 {
			 moveY = 5;
		 }
		 else if (pSpecies == "zylot")
		 {
			 moveY = 10;
		 }
		 
		 return moveY;
	 }
	public int getPhase() {
		return phase;
	}

	public void setPhase(int phase) {
		this.phase = phase;
	}

	public int getDigest() {
		return digest;
	}

	public void setDigest(int digest) {
		this.digest = digest;
	}

	public int getAge() {
		return age;
	}
	
	public void setAge(int age) {
		this.age = age;
	}

	public boolean isFull() {
		return full;
	}

	public void setFull(boolean full) {
		this.full = full;
	}



	public String getSpecies() {
		return species;
	}



	public void setSpecies(String species) {
		this.species = species;
	}
    
	public int getxCenter() {
		return xCenter;
	}

	public void setxCenter() {
		// the value of the phase + current xloc = center (due to pixel size of creatures)		
		int tempMidX = phase + xLoc;
		//System.out.println(tempMidX + "???");
		this.xCenter = tempMidX;
	}

	public int getyCenter() {
		return yCenter;
	}

	public void setyCenter() {		
		// the value of the phase + current yloc = center (due to pixel size of creatures)		
		int tempMidY = phase + yLoc;//image.getWidth(null) / 2 + yOrg;		
		//System.out.println(tempMidY + "???");
		this.yCenter = tempMidY;
	}
	
    
    public int getPixels() {
		return pixels;
	}



	public void setPixels(int pixels) {
		this.pixels = pixels;
	}

    //bounding rectangle
    public Rectangle getBoundingBox() {
        return boundingBox;
    }
    
    public void setBoundingBox() {
    	Rectangle myBox = new Rectangle(this.xLoc, this.yLoc, this.pixels, this.pixels);
    	this.boundingBox = myBox;
    } 
    
    
}
