package evo.cis306.app;

public class Spore extends StationaryCritter{
	
	public Spore()
	{
		super();
		
		
		
		
		
	}

	public Spore(int pX, int pY, int pPhase, int pDigest, int pAge, boolean pFull, String pSpecies, String pFileName)
	{	
		
		
		
		super(pX, pY, pPhase, pDigest, pAge, pFull, pSpecies, pFileName);
		
		
		
		
	}

}
