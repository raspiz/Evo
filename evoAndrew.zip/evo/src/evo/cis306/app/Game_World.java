package evo.cis306.app;

// settings of the world
public class Game_World {

	
	private int speed;
	private int generation;
	private int sporesReleased;
	private int sporeDistance;
	private int growChance; 	
	private int deepMaxAge;
	private int deathChance;
	
	
	
	// constructor
	public Game_World() {
		
		// need to make sure the values based on percent never exceed <0 and >99
		speed = 100; // base value. 100ms per cycle/year of the game
		generation = 0; // age of the game world
		sporesReleased = 100; // base value. 1 spore per turn released
		sporeDistance = 20; // base value. spore will move (20 spaces + size of parent) away from parent when released 
		growChance = 40; // base value. spore has a 40% to take root and grow into a new species
		deepMaxAge = 100; // base value. age after which deeproots will stop reproducing, phasing up, and may possibly die of old age
		deathChance = 5; // base value. critter has a 5% chance to die after reaching max age
	}


	
	/////////////////////////
	// accessors and mutators
	/////////////////////////
	
	public int getSpeed() {
		return speed;
	}



	public void setSpeed(int speed) {
		this.speed = speed;
	}



	public int getGeneration() {
		return generation;
	}



	public void setGeneration(int generation) {
		this.generation = generation;
	}
	
	
	public int getSporesReleased() {
		return sporesReleased;
	}

	public void setSporesReleased(int sporesReleased) {
		this.sporesReleased = sporesReleased;
	}



	public int getSporeDistance() {
		return sporeDistance;
	}



	public void setSporeDistance(int sporeDistance) {
		this.sporeDistance = sporeDistance;
	}



	public int getGrowChance() {
		return growChance;
	}



	public void setGrowChance(int growChance) {
		this.growChance = growChance;
	}



	public int getDeepMaxAge() {
		return deepMaxAge;
	}



	public void setDeepMaxAge(int deepMaxAge) {
		this.deepMaxAge = deepMaxAge;
	}



	public int getDeathChance() {
		return deathChance;
	}



	public void setDeathChance(int deathChance) {
		this.deathChance = deathChance;
	}

	
	
	
}
