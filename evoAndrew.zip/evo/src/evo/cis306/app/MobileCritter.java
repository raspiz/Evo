/* Raspiz: ok. you could make a MobileCritter class. 
 * it will need a data member for number of spaces to move. 
 * you could also make classes for the other species. 
 * you can get a basic overview of them on the original html page
 */
package evo.cis306.app;

	public class MobileCritter extends Critter{
 
		public MobileCritter()
		{ //default constructor
			super();
		}
		
		public MobileCritter(int pX, int pY, int pPhase, int pDigest, int pAge, boolean pFull, String pSpecies, String pFileName)
		{ //constructor
			super(pX, pY, pPhase, pDigest, pAge, pFull, pSpecies, pFileName);
			
		}	 

	}
	
