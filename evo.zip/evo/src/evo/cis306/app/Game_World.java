package evo.cis306.app;

// settings of the world
public class Game_World {

	
	//private int generation;
	private int generation;
	
	
	public final int DEEP_MAX_AGE = 10;
	
	
	
	// constructor
	public Game_World() {
		
		generation = 0;
		
	}


	
	///////////////////
	// accessors and mutators

	public int getGeneration() {
		return generation;
	}



	public void setGeneration(int generation) {
		this.generation = generation;
	}
	
	
	public int getDEEP_MAX_AGE()
	{
		return DEEP_MAX_AGE;
	}
	
	
	
	
	
}
