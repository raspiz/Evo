package evo.cis306.app;

public class Spore extends Critter{

}
