package evo.cis306.app;

public class Deeproot extends StationaryCritter{

	public Deeproot()
	{
		super();
		
		
		
		
		
	}

	public Deeproot(int pX, int pY, int pPhase, int pDigest, int pAge, boolean pFull, String pSpecies, String pFileName)
	{	
		
		
		
		super(pX, pY, pPhase, pDigest, pAge, pFull, pSpecies, pFileName);
		
		
		
		
	}

	
	
	
}
