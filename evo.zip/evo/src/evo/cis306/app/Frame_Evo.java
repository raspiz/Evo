package evo.cis306.app;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;


public class Frame_Evo extends JFrame{// implements Runnable{
	
	
	private Game_Evo pnlEvo;

	private Thread loop;
	
	

	
	public Frame_Evo()
	{
		pnlEvo = new Game_Evo();
		
		//pnlEvo.stopTimer();
		
		this.setTitle("EVO");
		this.setSize(500, 500);//pnlEvo.WIDTH, pnlEvo.HEIGHT);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
		
		
		// made a new thread. may want to change or remove
		//loop = new Thread(this);
		//loop.start();

		
		this.add(pnlEvo);
		//pnlEvo.startTimer();
	}
	
	

	
	
	
	
//	public void run()
//	{
//		while(true)
//		{
//			try
//			{
//				Thread.sleep(50);
//				//repaint();
//			}
//			catch(Exception e)
//			{
//				System.out.println("I can't sleep...");
//			}
//			
//			//enemy.updateSprite();
//			//checkCollisions();
//			//repaint();
//			
//		}
//	
//	}
	
	

	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Frame_Evo frame = new Frame_Evo();
		
		
		
		// attach this to a button
		frame.pnlEvo.startTimer();
		
//		int x = 0;
//		while(x < 10)
//		{
//			x++;
//		}
//		
//		frame.pnlEvo.stopTimer();
	}

}
