package evo.cis306.app;

import java.util.Random;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;
import java.util.ArrayList;
import javax.swing.*;


public class Game_Evo extends JPanel{
	
	public final int WIDTH = 300;
	public final int HEIGHT = 300;
	// Speed of game
	public final int SPEED = 500;
	

	private Random generator;
	
	
	// arraylist to hold individual species
	private ArrayList<Deeproot> deeproot;
	
	// arraylist of arraylists. each species is an index in the arraylist
	// 0  - deeproot
	private ArrayList critList;
	

	
	//ArrayList<ArrayList<Critter>> test = new ArrayList<>();
	
	
	private Game_World world;
	private Game_Evo game;

	
	private Critter currentCritter;
	
	private Timer timer;	

	
	
	

	
	//private Game_EVO game = new Game_EVO;
	
	
	public Game_Evo()
	{
		timer = new Timer(SPEED, new TimerListener());
		
		// load parameters for the game world
		// could derive classes from this for different testing and balancing
		world = new Game_World();
		
		// create deeproot arraylist and add it to total critter arraylist
		////**********************
		// need to add all species to this as they are implemented
		////**********************
		deeproot = new ArrayList<Deeproot>(20);	
		//critList = new ArrayList<ArrayList>(1);
		critList = new ArrayList();
				
		critList.add(deeproot);
		
		generator = new Random();			
	}
	

	/******************************
	 * POPULATE
	 * 
	 * at start of game and if there are less than 20 deeproots in the game,
	 * 20 deeproots will be populated
	 * 
	 * 
	 * 
	 ******************************/
	public void Populate()
	{		
		
		// might want to change condition here
		while (deeproot.size() < 5)// 20)			
		{
			int startX = 0;
			int startY = 0;
			
			
			// change condition here to account for 3x3 pixel size
			// may want to abstract out into a separate method
			do
			{
				startX = generator.nextInt(WIDTH);
				startY = generator.nextInt(HEIGHT);
				
			}while (startX > WIDTH || startX < 0 || startY > HEIGHT || startY < 0);
			
			System.out.println("x: " + startX + " | y: " + startY);
			
				// check for collisions and room to be added	
			
			
			

			// create default deeproot object
			currentCritter = new Deeproot(startX, startY, 1, 0, 0, false, "Deeproot", "deeproot1.png");
			currentCritter.loadImage();
			currentCritter.setImage(currentCritter.getImage());
			
				
				
				
				
				
			
				
			// add to arraylist
			// cast it as a deeproot
			deeproot.add((Deeproot)currentCritter);
			
			
				
				
			//System.out.println(currentCritter.getSpecies() + "  " + critters.size() + " X:" + currentCritter.getxLoc() + " Y:" + currentCritter.getyLoc());
			
		}
			
		


		
	}
	
	/*********************************
	 * THIS IS THE MAIN GAME FUNCTION.
	 * 
	 * CALLED EACH TIME THE TIMER TICKS
	 *********************************/
	private class TimerListener implements ActionListener
	{
	
		//private int time;
		
		//The listener that triggered when the timer goes off
		public void actionPerformed(ActionEvent arg0) 
		{
		
			
			// perform one cycle of the game
			
			//System.out.println("hello there");
			
			Populate();

			///// foreach loop
			// age up
			// check for growth
			// resize if growing		
			// if > phase 2, create spores 
			// die if too old
			// draw
			// 
			
			int count = 0;
			
			
	
			
			// cycle through each species behavior
			// age, phaseup, die, move, eat, etc
			for (int i = 0; i < critList.size(); i++)
			{
				Critter myCritter;
				
				switch (i)
				{
					// deeproot behavior
					case 0:
						for (int j = 0; j < deeproot.size(); j++)
						{

							
							// returns the creature as an object
							myCritter = deeproot.get(j);
							
							int vAge = myCritter.getAge();
							vAge++;
							myCritter.setAge(vAge);
							
							// age 1 year
							//deeproot.get(j).setAge(deeproot.get(j).getAge() + 1);
							
							
							if (vAge <= world.DEEP_MAX_AGE) // false if ready to die
							{
								
								
								
								// try to phase up
								
															
								int phaseUpInterval = world.DEEP_MAX_AGE / 5;
								
								
								
								if (vAge % phaseUpInterval == 0  )
								{
									if (myCritter.phase < 5)
									{
										
										
										// try to grow
										// change output image
										
										
										
										
										// phase up
										myCritter.setPhase(myCritter.getPhase() + 1);

										
										
										
										// concatenate a string for the filename
										myCritter.setFilename("deeproot" + myCritter.phase + ".png");										
										
										myCritter.loadImage();
										
										
										//player.setImage(explosion.getImage());
										
										//System.out.println("I am " + myCritter.getAge() + " and on phase " + myCritter.phase);// + " number + " + critters.size());

										
									}
									
									//myCritter
									
									
									
									
									
								}
								
								
								
								
							}
							else // die, remove
							{																
								myCritter = null;
								deeproot.remove(j);
								j--;
							}
							
							
							
						}						
	
						
						
						break;
				
				
				
				
				
				
				}
				
				

				
				
				//int xam = critList.get(i).get(i).getAge();
				
				//int yam = deeproot.get(i).getAge();
				
				
//				for (int j = 0; j < critList.get(i).size(); j++)
//				{
//					
//					
//					
//					
//				}
				
				
			}
			
		
		
			// age the world by 1
			world.setGeneration(world.getGeneration() + 1);
			
			repaint();
			
			
			
		
		}
	
	
	}
	
	//Start the timer object
	public void startTimer()
	{
		timer.start();
		
	
	}
	
	// Stop the timer object
	public void stopTimer()
	{
		timer.stop();
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		g.setColor(Color.RED);
		g.drawLine(200, 200, 300, 300);
		
		for (int i = 0; i < deeproot.size(); i++)
		{
			Critter d = deeproot.get(i);// = null;
			
			d.draw(g);
			
			//System.out.println(d.filename);
			
		}
		
		
	}

	
	
}
