/* Raspiz: ok. you could make a MobileCritter class. 
 * it will need a data member for number of spaces to move. 
 * you could also make classes for the other species. 
 * you can get a basic overview of them on the original html page
 */
package evo.cis306.app;

	public class MobileCritter extends Critter{
	protected int moveX, moveY, maxAge;	
 
	public MobileCritter()
	{ //default constructor
		super();
		moveX = 0;
		moveY = 0;
		maxAge = 0;
	}
	
	public MobileCritter(int pX, int pY, int pPhase, int pDigest, int pAge, boolean pFull, String pSpecies, String pFileName, String pType)
	{ //constructor
		super(pX, pY, pPhase, pDigest, pAge, pFull, pSpecies, pFileName, pType);
		MoveX(pSpecies);
		MoveY(pSpecies);
		MaxAge(pSpecies);
		
	}
	 public int MoveX(String pSpecies)
	 {   //check the species of the critter
		 //generate a random up to the max move value of the species
		 if (pSpecies == "chingling" )
		 {
			 moveX = 1;
		 }
		 else if (pSpecies == "marmot")
		 {
			 moveX = 5;
		 }
		 else if (pSpecies == "zylot")
		 {
			 moveX = 10;
		 }
		 return moveX;
	 }
	 public int MoveY(String pSpecies)
	 {
		 //same as above
		 if (pSpecies == "chingling" )
		 {
			 moveY = 1;
		 }
		 else if (pSpecies == "marmot")
		 {
			 moveY = 5;
		 }
		 else if (pSpecies == "zylot")
		 {
			 moveY = 10;
		 }
		 
		 return moveY;
	 }
	 public int MaxAge(String pSpecies)
	 {
		 if (pSpecies == "chingling" )
		 {
			 maxAge = 100;
		 }
		 else if (pSpecies == "marmot")
		 {
			 maxAge = 50;
		 }
		 else if (pSpecies == "zylot")
		 {
			 maxAge = 50;
		 }
		 
		 return maxAge;
	 }
	}
	
