package evo.cis306.app;

public class Catcher extends StationaryCritter{

	public Catcher()
	{
		super();
	}
	public Catcher(int pX, int pY, int pPhase, int pDigest, int pAge, boolean pFull, String pSpecies, String pFileName, String pType)
	{	
		super(pX, pY, pPhase, pDigest, pAge, pFull, pSpecies, pFileName, pType);
	}
	
}
