package evo.cis306.app;

import java.util.Random;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.*;


public class Game_Evo extends JPanel{
	
	private int width; 
	private int height;
	// Speed of game


	private Random generator;
	public final int SEEDS = 20; // critters to start with or spawn if everything dies
	
	// arraylist to hold individual species
	private ArrayList<Deeproot> deeproot;
	private ArrayList<Catcher> catcher;
	private ArrayList<Chingling> chingling;
	private ArrayList<Marmot> marmot;
	private ArrayList<Zylot> zylot;
	private ArrayList<Spore> spore;
	
	 private JPanel status;
	 private JLabel curWorldAge;
	 private JLabel curCatcher;
	 private JLabel curDeeproot;
	 private JLabel curChingling;
	 private JLabel curMarmot;
	 private JLabel curZylot;
	 private JLabel curCritter;
	 private JLabel curSpore;
	 private int totCrits;
	
	
	// arraylist of arraylists. each species is an index in the arraylist

	// 0  - deeproot
	// 1 - catcher
	// 2 - chingling
	// n-1 - spore - keep as last element in array		
	private ArrayList<ArrayList> critList;
	


	
	protected Game_World world;


	
	private Critter currentCritter;
	
	protected Timer timer;	


	public Game_Evo()
	{
		// load parameters for the game world
		// could derive classes from this for different testing and balancing
		world = new Game_World();
		
		PanelSize();		
		
		timer = new Timer(world.getSpeed(), new TimerListener());
		

		
		// create deeproot arraylist and add it to total critter arraylist
		////**********************
		// need to add all species to this as they are implemented
		////**********************
		deeproot = new ArrayList<Deeproot>();	
		catcher = new ArrayList<Catcher>();
		chingling = new ArrayList<Chingling>();
		marmot = new ArrayList<Marmot>();
		zylot = new ArrayList<Zylot>();
		spore = new ArrayList<Spore>();
		critList = new ArrayList<ArrayList>();
				

		critList.add(deeproot);
		critList.add(catcher);
		critList.add(chingling);
		critList.add(marmot);
		critList.add(zylot);
		// MAKE SURE SPORE IS ADDED TO THE ARRAYLIST LAST!
		critList.add(spore);
		
		generator = new Random();			
	}
	
	
	public void createStatusPanel(){
		//creates the status panel, which outputs the statuses of the critters and world
//		FlowLayout flow = new FlowLayout();


//		top= new JPanel(new FlowLayout());
		curWorldAge= new JLabel();
		curCritter= new JLabel();
		curCatcher= new JLabel();
		curDeeproot= new JLabel();
		curChingling= new JLabel();
		curMarmot= new JLabel();
		curZylot= new JLabel();
		curSpore= new JLabel();
		status = new JPanel(new FlowLayout());
//		curWorldAge.setText("World Age: "+ world.getGeneration()) ;
//		curCritter.setText("Total Critters: " + critList.size()  ) ;
//		curCatcher.setText("Catch: " + catcher.size() ) ;
//		curDeeproot.setText("Deep: " + deeproot.size()) ;
//		curChingling.setText("Ching: "); // + chingling.size()) ;
//		curMarmot.setText("Marm: " ); //+ marmot.size()) ;
//		curZylot.setText("Zylot: " ); //+ zylot.size()) ;
//		curSpore.setText("Spore: " + spore.size()) ;

		
		
		
		status.add( curWorldAge);
		status.add( curCatcher);
		status.add( curDeeproot);
		status.add( curChingling);
		status.add( curMarmot);
		status.add( curZylot);
		status.add( curSpore);	
		status.add( curCritter);

		this.add(status, BorderLayout.SOUTH);
		
	}

	/*********************************
	 * THIS IS THE MAIN GAME FUNCTION.
	 * 
	 * CALLED EACH TIME THE TIMER TICKS
	 *********************************/
	private class TimerListener implements ActionListener
	{
		
		//The listener that triggered when the timer goes off
		public void actionPerformed(ActionEvent arg0) 
		{			
			// perform one cycle of the game

			PanelSize();
			
			Populate();

			CritterBehavior();
		
			// age the world by 1
			world.setGeneration(world.getGeneration() + 1);
			
			curWorldAge.setText("WorldAge:"+ world.getGeneration()) ;
			curCritter.setText("TotalCrit:" + totCrits ) ;
			curCatcher.setText("Catch:" + catcher.size() ) ;
			curDeeproot.setText("Deep:" + deeproot.size()) ;
			curChingling.setText("Ching:" + chingling.size()) ;
			curMarmot.setText("Marm:" + marmot.size()) ;
			curZylot.setText("Zylot:" + zylot.size()) ;
			curSpore.setText("Spore:" + spore.size()) ;

			status.repaint();
			repaint(); // calls paintComponent and draws all of the creatures to the screen
			
			System.out.println("Generation: " + world.getGeneration());		
		}
	
	
	}
	
	/*********************************
	 * CritterBehavior - loops through all critters currently in the game. Called by the timer
	 */
	public void CritterBehavior()
	{
		///// foreach loop
		// age up
		// check for growth
		// resize if growing
		// full check
		// if mobile, move or eat
		// if > phase 2, create spores 
		// die if too old
		// draw
		// 
		
		for (int i = 0; i < critList.size(); i++)
		{
			Critter myCritter;
			
			ArrayList<Critter> speciesList = (ArrayList<Critter>)critList.get(i);			
			
			if (speciesList != null)  // makes sure this will not cause an error when a species goes extinct
			{
				for (int j = 0; j < speciesList.size(); j++)
				{
					myCritter = speciesList.get(j);
					
					// age 1 year
					
					int vAge = CritterAgeUp(myCritter, myCritter.age);						
					
					if (vAge <= world.getMaxAge(i)) // false if ready to die
					{	
						if (!myCritter.species.equals("spore")) // everyone except spores 	
						{
							int phaseUpInterval = world.getMaxAge(i) / 5;	
							
							// try to phase up
							if (vAge % phaseUpInterval == 0)
							{								
								if (myCritter.phase < 5)
								{									
									// try to grow
									// if it grows, change set the x and y centers with critter.UpdateSprite();

									if (CritterPhaseUp(myCritter))
									{
										// change output image. concatenate a string for the filename
										myCritter.setFilename(myCritter.species + myCritter.phase + ".png");	
										myCritter.loadImage();	
									}															
								}									
							}
							
							// movement
							if (myCritter.type.equals("mobile"))
							{
								// get max moves for critter and randomize allowed moves. critter will get 1 to n moves where n is maxMoves
								int currentMoves = generator.nextInt(world.getMaxMoves(i)) + 1;
								
								while (currentMoves > 0)
								{
												
									// if no collide, move is goood
									CritterMove(myCritter);
									
									
									
									currentMoves--;
								}
								
								
							}
							
							int sporesOut = world.getSporesReleased();
							
						    // 100 means 1 spore, 150 means 1.5 spores, etc
							// can't remember why i did it this way. could be tweaked
				            if (myCritter.phase > 2)	// create spores if they are past the 2 phase
				                if (sporesOut >= 150)
				                {
				                    CreateSpore(myCritter);
				                    if (sporesOut >= 200 && myCritter.age % 20==0)//2 == 0)
				                        CreateSpore(myCritter);
				                }
				                else if (sporesOut >= 50)                    
				                    if (sporesOut >= 100 && myCritter.age % 20==0)//2 == 0)
				                        CreateSpore(myCritter);		
						}	
						else // spore behavior
						{	
							if (SporeBehavior(myCritter))
							{								
				                // delete spore
				                spore.remove(j);
				                j--;
							}								
						}
					}
					else
					{		
						
						// after a certain age they will no longer reproduce or try to phase up. each cycle there is a chance they will die and be removed
						
						// made this a chance to die after a certain age rather than certain death
						// could make this affected by weather, temp zone, species
						if (generator.nextInt(100) < world.getDeathChance())
						{
							myCritter = null;
							speciesList.remove(j);
							j--;
						}
					}						
				}
			}	
		}			
	}
	
	
	
	
	
	public boolean SporeBehavior(Critter pCritter)
	{
		
    	int mutate = generator.nextInt(100); // 0 to 99. could parameterize this and make the chance of mutation go up or down based on conditions or temp zone
		  
    	// not done yet							        	
    	// add another condition above here for each species added	
    	// need to account for additional size of phase 1 creature, check for collisions
        // trying up 2, down 1 for evolve for now
        // species can only mutate 2 above and 1 below itself           
        // spore will mutate into a new species if random number is within range  		
    	
    	//System.out.println("my species is " + myCritter.species);
    	
        if (mutate <= 5 && ((pCritter.parent.equals("zylot") || pCritter.parent.equals("marmot"))))	// 5% chance to mutate to zylot
        {
        	// if the creature is able to phase up, that means there was no collision and it's safe to be "born"
			if (CritterPhaseUp(pCritter))
			{
				// create the baby
                currentCritter = new Zylot(pCritter.xLoc, pCritter.yLoc, pCritter.phase, pCritter.digest, 0, pCritter.full, "zylot", "zylot1.png", "mobile");

                // birth it into the world
				zylot.add((Zylot)currentCritter);	
				
				return true;
			}		
        }    	
        else if (mutate <= 10 && ((pCritter.parent.equals("zylot") || pCritter.parent.equals("marmot") || pCritter.parent.equals("chingling"))))	// 5% chance to mutate to marmot
        {
        	// if the creature is able to phase up, that means there was no collision and it's safe to be "born"
			if (CritterPhaseUp(pCritter))
			{
				// create the baby
                currentCritter = new Marmot(pCritter.xLoc, pCritter.yLoc, pCritter.phase, pCritter.digest, 0, pCritter.full, "marmot", "marmot1.png", "mobile");

                // birth it into the world
				marmot.add((Marmot)currentCritter);	
				
				return true;
			}		
        }    	
        else if (mutate <= 15 && ((pCritter.parent.equals("marmot") || pCritter.parent.equals("chingling") || pCritter.parent.equals("catcher"))))	// 5% chance to mutate to chingling
        {
        	// if the creature is able to phase up, that means there was no collision and it's safe to be "born"
			if (CritterPhaseUp(pCritter))
			{
				// create the baby
                currentCritter = new Chingling(pCritter.xLoc, pCritter.yLoc, pCritter.phase, pCritter.digest, 0, pCritter.full, "chingling", "chingling1.png", "mobile");

                // birth it into the world
				chingling.add((Chingling)currentCritter);	
				
				return true;
			}		
        }    	
        else if (mutate <= 20 && ((pCritter.parent.equals("chingling") || pCritter.parent.equals("catcher") || pCritter.parent.equals("deeproot"))))	// 5% chance to mutate to catcher
        {
        	// if the creature is able to phase up, that means there was no collision and it's safe to be "born"
			if (CritterPhaseUp(pCritter))
			{
				// create the baby
                currentCritter = new Catcher(pCritter.xLoc, pCritter.yLoc, pCritter.phase, pCritter.digest, 0, pCritter.full, "catcher", "catcher1.png", "stationary");

                // birth it into the world
				catcher.add((Catcher)currentCritter);	
				
				return true;
			}
        }	
        else if (mutate <= world.getGrowChance() && (pCritter.parent.equals("deeproot") || pCritter.parent.equals("catcher")))  // chance to grow into deeproot, based on user control
        {
        	// if the creature is able to phase up, that means there was no collision and it's safe to be "born"
			if (CritterPhaseUp(pCritter))
			{
				// create the baby
                currentCritter = new Deeproot(pCritter.xLoc, pCritter.yLoc, pCritter.phase, pCritter.digest, 0, pCritter.full, "deeproot", "deeproot1.png", "stationary");

                // birth it into the world
				deeproot.add((Deeproot)currentCritter);	

				return true;
			}
        }			
		
		
		return false;
		
		
	}
	

	
	
	
	/******************************
	 * Populate - at start of game and if there are less than 20 deeproots in the game,
	 * 20 deeproots will be populated
	 ******************************/
	public void Populate()
	{		
		int stuckCount = 0; // safeguard to avoid an infinite loop if there is no room
		
		// might want to change condition here. could make it spawn spores rather than deeproots
		while (deeproot.size() < SEEDS && stuckCount < 1000)			
		{
			int startX = 0;
			int startY = 0;			

			startX = generator.nextInt(width); // 0 to (n-1)
			startY = generator.nextInt(height);			
	
			currentCritter = new Deeproot(startX, startY, 1, 0, 0, false, "deeproot", "deeproot1.png", "stationary");	
			
			// check for collisions and room to be added
			if (!CollisionDetect(currentCritter))
			{				
				//currentCritter.loadImage();
				//currentCritter.setImage(currentCritter.getImage());
				
				deeproot.add((Deeproot)currentCritter);	// add to arraylist.	cast it as a deeproot				
			}
			
			stuckCount++;			
		}
	}	
	
	/************************
	 * CreateSpore - called when an existing critter wants to release a spore.
	 * a creature is passed in and a spore of that species will be born
	 * 
	 * @param pParent
	 * @param pSpecies
	 ***********************/
	public void CreateSpore(Critter pParent)
	{
		int spawnX = 0;
		int spawnY = 0;
		int dirX, dirY;
		boolean collision = false; // local flag
		int distance = world.getSporeDistance(); // distance spore can travel away from parent based on game world parameter
		
		// find a random spawn point from 0-distance away from parent.
		// tacks on parent size based on phase so that spore does not spawn on top of parent
		switch (pParent.getPhase())
		{
			case 1:
	            spawnX = generator.nextInt(distance) + 2;	
	            spawnY = generator.nextInt(distance) + 2;	
				break;
			case 2:
	            spawnX = generator.nextInt(distance) + 3;	
	            spawnY = generator.nextInt(distance) + 3;	
				break;
			case 3:
	            spawnX = generator.nextInt(distance) + 5;	
	            spawnY = generator.nextInt(distance) + 5;	
				break;
			case 4:
	            spawnX = generator.nextInt(distance) + 7;	
	            spawnY = generator.nextInt(distance) + 7;	
				break;
			case 5:
	            spawnX = generator.nextInt(distance) + 9;	
	            spawnY = generator.nextInt(distance) + 9;	
				break;	
		}
		
		// determine if the spore moves north/south and east/west
	    dirX = generator.nextInt(2);
	    dirY = generator.nextInt(2);
	    
	    if (dirX == 0)	// east
	    {
	        spawnX = pParent.getxCenter() + spawnX;
	        if (dirY == 0)	// north						
	            spawnY = pParent.getyCenter() - spawnY;						
	        else	// south						
	            spawnY = pParent.getyCenter() + spawnY;						
	    }
	    else	// west
	    {
	        spawnX = pParent.getxCenter() - spawnX;
	        if (dirY == 0)	// north						
	            spawnY = pParent.getyCenter() - spawnY;						
	        else	// south						
	            spawnY = pParent.getyCenter() + spawnY;						
	    } 
		
	    // create spore. not added to arraylist until we're 
	    //sure it won't collide with an existing creature
	    // or spawn out of bounds
	    currentCritter = new Spore(spawnX, spawnY, 0, 0, 0, false, "spore", "spore.png", "stationary", pParent.species);
	    
	    if (spawnX >= 0 && spawnX < width && spawnY >= 0 && spawnY < height) // make sure spawn loc is within borders
	    	collision = false; 	    
	    else
	    	collision = true;	    

	    if (!collision)
	    	collision = CollisionDetect(currentCritter); // try to collide with all of the other creatures	    
	    
	    // if all good, add to spore arraylist
	    if(!collision)	    
	    	spore.add((Spore)currentCritter);		
	}	
	
	/************************
	 * CritterMove - move one pixel in a random direction
	 * 
	 * 
	 * 
	 * @param pCritter
	 ************************/
	public void CritterMove(Critter pCritter)
	{
		// choose a direction. 0 - north, 1 - south, 2 - west, 3 - east
		int dir = generator.nextInt(4);			
		
		// tentatively move in the new direction
		if (dir == 0)
			pCritter.setyLoc(pCritter.getyLoc() - 1);
		else if (dir == 1)
			pCritter.setyLoc(pCritter.getyLoc() + 1);
		else if (dir == 2)
			pCritter.setxLoc(pCritter.getxLoc() - 1);
		else
			pCritter.setxLoc(pCritter.getxLoc() + 1);
		
		pCritter.updateSprite();

		// try to collide with border and other critters
		if (pCritter.xLoc < 0 || pCritter.yLoc < 0 || pCritter.xLoc >= (width + pCritter.pixels) 
				|| pCritter.yLoc >= (height + pCritter.pixels)
				|| CollisionDetect(pCritter)) 
		{
			// revert changes
			if (dir == 0)
				pCritter.setyLoc(pCritter.getyLoc() + 1);
			else if (dir == 1)
				pCritter.setyLoc(pCritter.getyLoc() - 1);
			else if (dir == 2)
				pCritter.setxLoc(pCritter.getxLoc() + 1);
			else
				pCritter.setxLoc(pCritter.getxLoc() - 1);
			
			pCritter.updateSprite();											
		}	
		
		
		// if hunting different conditions
		
		
		
		
		
		
	}
	
	
	
	
	/*******************
	 * CollisionDetect - passed in critter will try to collide with all other creatures.
	 * used for reproducing, phasing up, moving, and eating
	 * critter will not check against itself
	 * 
	 * @param pMovingCritter - the critter trying to collide
	 * @return - true if there is a collision, false if there is not
	 *********************/
	public boolean CollisionDetect(Critter pMovingCritter)
	{
		Critter daGuy; // critter trying to be collided with.
		
		// this loop will pull in every critter in the game try to collide with it
		for (int i = 0; i < critList.size(); i++)
		{			
			// POLYMORPHISM!
			ArrayList<Critter> speciesList = (ArrayList<Critter>)critList.get(i);
			
			for (int j = 0; j < speciesList.size(); j++)
			{				
				daGuy = speciesList.get(j);				
				
				if (!pMovingCritter.equals(daGuy)) // this seems to work as it should. keeps from colliding with itself
					if (pMovingCritter.boundingBox.intersects(daGuy.boundingBox))	// calling the intersects function of Rectangle Class			    	
			    		return true; // we have a collision
			}			
		}	

		return false; // no collision
	}
	
	
	/***********************
	 * CritterPhaseUp - critter will try to reach a new phase by increasing in size.
	 * first it will phase up and then try to collide to make sure there was room
	 * if there is a collision or phasing up would put it out of game bounds it will phase back down
	 * 
	 * @param pCritter - the critter trying to phase up
	 * @return false if it was unable to phase up, true if it was
	 */
	public boolean CritterPhaseUp(Critter pCritter)
	{
		// phase up
		pCritter.setPhase(pCritter.getPhase() + 1);
		// move critter up and left 1 space to keep growth radius centered											
		pCritter.setxLoc(pCritter.getxLoc() - 1);
		pCritter.setyLoc(pCritter.getyLoc() - 1);
		pCritter.updateSprite();		

		// try to collide. if there is a collision, reset phase and size
		if(CollisionDetect(pCritter) || pCritter.getxLoc() < 0 || pCritter.getxLoc() >= width || pCritter.getyLoc() < 0 || pCritter.getyLoc() >= height)
		{
			pCritter.setPhase(pCritter.getPhase() - 1);
			pCritter.setxLoc(pCritter.getxLoc() + 1);
			pCritter.setyLoc(pCritter.getyLoc() + 1);

			pCritter.updateSprite();

			return false;	// unable to phase up
		}
				
		return true; // phase up successful
	}
	
	/************************
	 * CritterAgeUp - increment the passed in critter's age 1 year and return the value
	 * the age is set here but also returned to use for other purposes
	 * 
	 * @param pCritter - critter that is aging
	 * @param pAge - current age
	 * @return - new age
	 ***********************/
	public int CritterAgeUp(Critter pCritter, int pAge)
	{
		pAge++;		
		pCritter.setAge(pAge);	
		return pAge;		
	}
	
	
	//Start the timer object
	public void startTimer()
	{
		timer.start();	
	}
	
	// Stop the timer object
	public void stopTimer()
	{
		timer.stop();
	}
	
	
	
	/**********************
	 * paintComponent - draw the creatures to the screen at the end of every cycle of the timer
	 * 
	 * 
	 *********************/
	public void paintComponent(Graphics g)
	{
		totCrits = 0;
		super.paintComponent(g);
		
		//g.setColor(Color.RED);
		//g.drawLine(200, 200, 300, 300);
		
		Critter c;
		
		for (int i = 0; i < critList.size(); i++)
		{	
			// POLYMORPHISM!
			ArrayList<Critter> speciesList = (ArrayList<Critter>)critList.get(i);
			
			for (int j = 0; j < speciesList.size(); j++)
			{
				totCrits++;
				c = speciesList.get(j);
				c.draw(g);
			}			
		}		
	}
	
	/*********************
	 * PanelSize - assigns the game's panel to the max size within the JFrame it sits in
	 * several pixels are subtracted from the width and height to prevent critters from
	 * getting outside of the borders. 
	 *********************/
	public void PanelSize()
	{
		// reducing this by 6 keeps them within the actual window border
		width = this.getWidth() - 6;
		height = this.getHeight() - 6;		
	}	
}
