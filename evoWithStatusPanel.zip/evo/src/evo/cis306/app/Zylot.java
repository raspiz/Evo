package evo.cis306.app;

public class Zylot extends MobileCritter{
	public Zylot()
	{//default
		super();
	}
	public Zylot(int pX, int pY, int pPhase, int pDigest, int pAge, boolean pFull, String pSpecies, String pFileName)
	{
		super(pX, pY, pPhase, pDigest, pAge, pFull, pSpecies, pFileName);	
//		int MoveX = super.MoveX("zylot");
//		int MoveY =  super.MoveY("zylot");
//		int MaxAge = super.MaxAge("zylot");
	}
	
	
}
