package evo.cis306.app;

public class Marmot extends MobileCritter{

	public Marmot()
	{//default
		super();
	}
	public Marmot(int pX, int pY, int pPhase, int pDigest, int pAge, boolean pFull, String pSpecies, String pFileName)
	{
		super(pX, pY, pPhase, pDigest, pAge, pFull, pSpecies, pFileName);	
		int MoveX =  super.MoveX("marmot");
		int MoveY = super.MoveY("marmot");
		int MaxAge = super.MaxAge("marmot");

	}
	
}
